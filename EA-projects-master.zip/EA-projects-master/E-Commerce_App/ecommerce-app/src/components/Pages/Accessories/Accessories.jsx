import React from "react";

const Accessories = () => {
  return <div>Accessories</div>;
};

export default Accessories;
