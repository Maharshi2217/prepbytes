import React from "react";
import Button from "@mui/material/Button";

const Register = () => {
  return (
    <Button variant="outlined" href="#outlined-buttons">
      Register
    </Button>
  );
};

export default Register;
