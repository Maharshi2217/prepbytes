import React from "react";

const IPad = () => {
  return <div>IPad</div>;
};

export default IPad;
