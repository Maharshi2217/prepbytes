import React from "react";

const Macbook = () => {
  return <div>Macbook</div>;
};

export default Macbook;
